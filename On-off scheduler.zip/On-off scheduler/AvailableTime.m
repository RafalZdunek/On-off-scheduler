function [B,time_slots] = AvailableTime(t_plugin,t_plugoff,T)

B = [];
[N1,T1] = size(t_plugin); [N2,T2] = size(t_plugoff);
if (N1 ~= N2) | (T1 ~= T2)
    disp('Wrong timetable sizes');
    return
else
    N = N1;
end

% Columns: years, months, days, hourse, minutes, seconds 
t_now = datetime('now'); 
t_end = t_now + hours(12); 
Tx = zeros(1,N);
for n = 1:N
    tx = etime(t_plugoff(n,:),datevec(t_now))/3600; % hourse
    if tx < 0
        tx = min(12,tx + 24); 
    end
    Tx(n) = round(tx*T/12); % available times slots
end
time_slots = t_now + minutes(720/T*(0:1:T));

% Matrix B
B = zeros(T,N);
Tin = ones(1,N); % initial time slots
for n = 1:N
    B(Tin(n):Tx(n),n) = 1; % binary matrix of avilable time slots for each EV
end

end