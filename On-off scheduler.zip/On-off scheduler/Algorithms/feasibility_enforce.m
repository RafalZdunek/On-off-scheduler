function [C_new,uc] = feasibility_enforce(C,B,param)

%% Constraints
method = param.method_feasible;
N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Inequality Constraints 
%B_tilde = kr(B,diag(param.r0*ones(1,N)))'; % B_tilde u = C
Z_tilde_X = kron(eye(T),param.I_EVs_X'); % Z_tilde u <= c_tilde (phase 1)
Z_tilde_Y = kron(eye(T),param.I_EVs_Y'); % Z_tilde u <= c_tilde (phase 2)
Z_tilde_Z = kron(eye(T),param.I_EVs_Z'); % Z_tilde u <= c_tilde (phace 3)
K_tilde = [Z_tilde_X; Z_tilde_Y; Z_tilde_Z]; % augmented matrix for inequality constraints

c_tilde_X = zeros(T,1); c_tilde_X(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Y = zeros(T,1); c_tilde_Y(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Z = zeros(T,1); c_tilde_Z(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
w_tilde = [c_tilde_X; c_tilde_Y; c_tilde_Z];

R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
a = param.r0*ones(N,1);
Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex

%% Equalities constraints 
K_eq = kron(ones(1,T),eye(N));

% Objective function
D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
G = ones(N,T)*D;
f = G(:);
BL = B';
inx = find(BL(:)); % indices of non-zero variables 
options = optimoptions('intlinprog','Heuristics','round','IntegerPreprocess','advanced',...
    'HeuristicsMaxNodes',500,'Display','off','MaxTime',param.Time_BLP);
% ================================================================
C_new = C; lx = 0;
PotentialConflictInx = (C > .5*(sum(B,1))'); % binary indices of the EVs which require the energy demand higher than their half plugging time
uc = []; % initialization

switch method

    case 1 %% Heuristics: all above the critical point           
    
            while isempty(uc) & sum(C_new(PotentialConflictInx)) > 0 
                  C_new(PotentialConflictInx) = max(0,C_new(PotentialConflictInx) - 1);
                  uc = intlinprog(f(inx),1:length(inx),[K_tilde(:,inx); R_tilde(:,inx)], [w_tilde; ex],K_eq(:,inx),C_new, ...
                       zeros(length(inx),1),ones(length(inx),1),options);     
                  lx = lx + 1; 
            end  
            disp(['Max(c) = ',num2str(max(C)),', Deepness in C to correct: ',num2str(lx)]);
            inx_stop = 0;
            pci = find(PotentialConflictInx); % numerical indices of EVs which should be updated
            for j = 1:length(pci)        
                for j_inc = 1:lx
                    C_new(pci(j)) = C_new(pci(j)) + 1;
                    ucc = intlinprog(f(inx),1:length(inx),[K_tilde(:,inx); R_tilde(:,inx)], [w_tilde; ex],K_eq(:,inx),C_new, ...
                       zeros(length(inx),1),ones(length(inx),1),options);   
                     if isempty(ucc)
                         C_new(pci(j)) = C_new(pci(j)) - 1;
                         inx_stop = 1;
                         break
                     else
                         uc = ucc;
                     end
                end % for j_inc    
                if inx_stop > 0
                    break
                end
            end % for j            
       
    case 2  %% Heristics: one worst point

            pci = find(PotentialConflictInx);
            for j = 1:length(pci)
                Ci = C_new(pci(j));
                while (C_new(pci(j)) > 1) & isempty(uc) 
                    C_new(pci(j)) = C_new(pci(j)) - 1;
                    uc = intlinprog(f(inx),1:length(inx),[K_tilde(:,inx); R_tilde(:,inx)], [w_tilde; ex],K_eq(:,inx),C_new, ...
                       zeros(length(inx),1),ones(length(inx),1),options);                      
                end % while
                if C_new(pci(j)) == 1
                   C_new(pci(j)) = Ci;
                end
                disp(['EV Inx: ',num2str(pci(j)),', Cj_ini = ',num2str(Ci),', Ci_stop = ',num2str(C_new(pci(j)))]);
            end % for j
            if isempty(uc)
                disp('One-point correction is not sufficient');
            end
        
    end % switch

end % function

