% Nonlinear Linear Programming (NLP)
%
%% Input: 
% B - matrix of availbale time slots
% C - vector of energy demands
% parameters

%% Output
% U - binary matrix of output controlling variables 

function [U,output] = BQP_2links_AC3_C_optim_fun(B,C,param)

N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Inequalities constraints 
%B_tilde = kr(B,diag(param.r0*ones(1,N)))'; % B_tilde u = C
Z_tilde_X = kron(eye(T),param.I_EVs_X'); % Z_tilde u <= c_tilde (phase 1)
Z_tilde_Y = kron(eye(T),param.I_EVs_Y'); % Z_tilde u <= c_tilde (phase 2)
Z_tilde_Z = kron(eye(T),param.I_EVs_Z'); % Z_tilde u <= c_tilde (phace 3)

R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
K_tilde = [Z_tilde_X; Z_tilde_Y; Z_tilde_Z]; % augmented matrix for inequality constraints
%a = param.r0*ones(N,1);
a = ones(N,1);

Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex
c_tilde_X = zeros(T,1); c_tilde_X(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Y = zeros(T,1); c_tilde_Y(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Z = zeros(T,1); c_tilde_Z(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
w_tilde = [c_tilde_X; c_tilde_Y; c_tilde_Z];

%% Equalities constraints 
K_eq = kron(ones(1,T),eye(N));

%% Objective function
D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
G = ones(N,T)*D;
f = G(:);

%% QP
%% Difference operator
L = eye(T) - diag(ones(T-1,1),1);
QL =  kron(L'*L,eye(N));
Q = .5*kron(sum(D,2)*sum(D,2)',eye(N)) + param.alpha*QL;
d = -(C'*kron(ones(1,T)*D,eye(N)))';

%% Algorithm
u = [];
u0 = rand([length(f),1]); BL = B';  
inx = find(BL(:));     
uc = BQP_alter_function(f(inx),Q(inx,inx),d(inx),[K_tilde(:,inx); R_tilde(:,inx)],[w_tilde; ex], K_eq(:,inx), C, inx, param);      
       
if isempty(uc)
    disp('Empty vector u');
   return
end
u = zeros(m,1);
u(inx) = uc;
U = reshape(u,[N T]);

% Output parameters
S = kron(eye(N/2),ones(1,2));
Ksm = S*U;

output.kmax_charge = max(Ksm(:)); % maximum number of charging EVs at any charging station
output.obj = .5*u'*Q*u + d'*u; 
output.obj_smooth = u'*QL*u;
output.counts = count_switches(U);
output.tardiness = max(find(sum(U,1))); 
output.power_max = param.Uc*(sum(diag(param.I_EVs_X)*U,1)+sum(diag(param.I_EVs_Y)*U,1)+sum(diag(param.I_EVs_Z)*U,1));
output.res_C_norm = norm(C - sum(U,2));
output.res_C = C - sum(U,2);
output.max_current_X = sum((param.I_EVs_X*ones(1,T)).*U,1);
output.max_current_Y = sum((param.I_EVs_Y*ones(1,T)).*U,1);
output.max_current_Z = sum((param.I_EVs_Z*ones(1,T)).*U,1);

end

