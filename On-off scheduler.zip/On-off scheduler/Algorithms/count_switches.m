function Z = count_switches(U)

[N,T] = size(U);
Zt = zeros([N,T-1]);

    for n = 1:N
        for t = 1:T-1
            if (U(n,t) - U(n,t+1)) < 0
               Zt(n,t) = 1;
            end
        end
    end

Z = sum(Zt(:));    
end