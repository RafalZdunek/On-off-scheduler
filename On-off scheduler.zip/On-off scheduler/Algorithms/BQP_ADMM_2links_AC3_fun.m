% Binary Linear Programming (BLP)
%
%% Input: 
% B - matrix of availbale time slots
% C - vector of energy demands
% parameters

%% Output
% U - binary matrix of output controlling variables 

function [U,output] = BQP_ADMM_2links_fun(B,C,param)

N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Inequality Constraints 
%B_tilde = kr(B,diag(param.r0*ones(1,N)))'; % B_tilde u = C
Z_tilde_X = kron(eye(T),param.I_EVs_X'); % Z_tilde u <= c_tilde (phase 1)
Z_tilde_Y = kron(eye(T),param.I_EVs_Y'); % Z_tilde u <= c_tilde (phase 2)
Z_tilde_Z = kron(eye(T),param.I_EVs_Z'); % Z_tilde u <= c_tilde (phace 3)
K_tilde = [Z_tilde_X; Z_tilde_Y; Z_tilde_Z]; % augmented matrix for inequality constraints

c_tilde_X = zeros(T,1); c_tilde_X(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Y = zeros(T,1); c_tilde_Y(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Z = zeros(T,1); c_tilde_Z(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
w_tilde = [c_tilde_X; c_tilde_Y; c_tilde_Z];

R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
a = param.r0*ones(N,1);
Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex

%% Equalities constraints 
K_eq = kron(ones(1,T),eye(N));

%% Difference operator
L = eye(T) - diag(ones(T-1,1),1);
QL = kron(L*L',eye(N));
D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);

F = kron(D,ones(1,N));
Q = kron(D,a*a') + param.alpha*QL;
d = -[F; F; F]'*w_tilde; % vector in the objective: 1/2 x'Qx + d'x

% Frank–Wolfe algorithm
% https://math.stackexchange.com/questions/3599474/solving-quadratic-programming-problem-using-linear-programming-solver
% https://www.mathworks.com/help/releases/R2020b/gads/surrogateopt.html#mw_e214512e-29e5-4306-a3d4-d3a49e9d80aa
%u = zeros(m,1);

% % Objective function
% D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
% G = ones(N,T)*D;
% f = G(:);

% Algorithm
u = [];
u0 = rand([length(d),1]); BL = B';
inx = find(BL(:)); % indices of non-zero variables 
all_param.x0 = u0(inx);

% options = optimoptions('intlinprog','Heuristics','advanced','IntegerPreprocess','advanced','HeuristicsMaxNodes',500);
% u = intlinprog(f,1:T*N,K_tilde,w_tilde,[kron(param.r0*ones(1,T),eye(N))],[C], ...
%         zeros(T*N,1),BL(:),u0.*BL(:)); 
 [x_sol,uc,obj_list,constraint_violation,y1,y2,y3,time_elapsed] = ADMM_bqp_linear_eq_ineq(Q(inx,inx),d(inx),...
     K_eq(:,inx),C,[K_tilde(:,inx); R_tilde(:,inx)], [w_tilde; ex],all_param);    

if isempty(uc)
    disp('Empty vector u');
   return
end
u = zeros(m,1);
u(inx) = uc;
U = reshape(u,[N T]);

% Output parameters
S = kron(eye(N/2),ones(1,2));
Ksm = S*U;

output.kmax_charge = max(Ksm(:)); % maximum number of charging EVs at any charging station
output.obj = .5*u'*Q*u + d'*u; 
output.obj_smooth = u'*QL*u; 
output.res_C_norm = norm(C - sum(U,2));
output.res_C = C - sum(U,2);

end