% Binary Linear Programming (BLP)
%
%% Input: 
% B - matrix of availbale time slots
% C - vector of energy demands
% parameters

%% Output
% U - binary matrix of output controlling variables 

function U = BLP_2links_fun(B,C,param)

N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Constraints 
%B_tilde = kr(B,diag(param.r0*ones(1,N)))'; % B_tilde u = C
Z_tilde = kron(eye(T),ones(1,N)); % Z_tilde u <= c_tilde
R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
K_tilde = [Z_tilde; R_tilde]; % augmented matrix for inequality constraints
a = param.r0*ones(N,1);

Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex
c_tilde = zeros(T,1); c_tilde(1:max(sum(B,1))) = param.P/param.r0; % assuming D = 0;
w_tilde = [c_tilde; ex];

% Objective function
D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
G = ones(N,T)*D;
f = G(:);

% Algorithm
u = [];
u0 = rand([length(f),1]); BL = B';
% Matlab 2021
%options = optimoptions('intlinprog','Heuristics','advanced','IntegerPreprocess','advanced','HeuristicsMaxNodes',500);
%u = intlinprog(f,1:T*N,K_tilde,w_tilde,[kron(ones(1,T),eye(N))],[C/param.r0], ...
%        zeros(T*N,1),BL(:),u0.*BL(:),options); 
    
% Matlab 2016
options = optimoptions('intlinprog','Heuristics','round','IntegerPreprocess','advanced','HeuristicsMaxNodes',500);
u = intlinprog(f,1:T*N,K_tilde,w_tilde,[kron(ones(1,T),eye(N))],[C/param.r0], ...
        zeros(T*N,1),BL(:),options); 
    
if isempty(u)
    disp('Empty vector u');
   return
end
U = reshape(u,[N T]);

end