% Binary Linear Programming (BLP)
%
%% Input: 
% B - matrix of availbale time slots
% C - vector of energy demands
% parameters

%% Output
% U - binary matrix of output controlling variables 

function [U,output] = FW_BQP_2links_AC3_fun(B,C,param)

N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Inequality Constraints 
%B_tilde = kr(B,diag(param.r0*ones(1,N)))'; % B_tilde u = C
Z_tilde_X = kron(eye(T),param.I_EVs_X'); % Z_tilde u <= c_tilde (phase 1)
Z_tilde_Y = kron(eye(T),param.I_EVs_Y'); % Z_tilde u <= c_tilde (phase 2)
Z_tilde_Z = kron(eye(T),param.I_EVs_Z'); % Z_tilde u <= c_tilde (phace 3)
K_tilde = [Z_tilde_X; Z_tilde_Y; Z_tilde_Z]; % augmented matrix for inequality constraints

c_tilde_X = zeros(T,1); c_tilde_X(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Y = zeros(T,1); c_tilde_Y(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
c_tilde_Z = zeros(T,1); c_tilde_Z(1:max(sum(B,1))) = param.Imax; % assuming D = 0;
w_tilde = [c_tilde_X; c_tilde_Y; c_tilde_Z];

R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
%a = param.r0*ones(N,1);
a = ones(N,1);
Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex

%% Equalities constraints 
K_eq = kron(ones(1,T),eye(N));

%% Difference operator
L = eye(T) - diag(ones(T-1,1),1);
QL = kron(L*L',eye(N));

%D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
D = diag([param.w_max - ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1, ones(1,param.t_stop)]);

F = kron(D,ones(1,N));
Q = -kron(D,a*a') + param.alpha*QL;
d = -[F; F; F]'*(w_tilde/param.r0); % vector in the objective: 1/2 x'Qx + d'x

% Algorithm
BL = B';
inx = find(BL(:)); % indices of non-zero variables 
uc = zeros(length(inx),1);
u0 = rand([length(inx),1]);

options = optimoptions('intlinprog','Heuristics','advanced','IntegerPreprocess','advanced','HeuristicsMaxNodes',500);

for k = 1:5    
    g = Q(inx,inx)*uc + d(inx);    
    s = intlinprog(g,1:length(inx),[K_tilde(:,inx); R_tilde(:,inx)],[w_tilde; ex],K_eq(:,inx),C, ...
        zeros(length(inx),1),ones(length(inx),1)); 
    gamma = 2/(2 + k);
    uc = uc + gamma*(s - uc);
end

if isempty(s)
    disp('Empty vector u');
   return
end
u = zeros(m,1);
u(inx) = s;
U = reshape(u,[N T]);

% Output parameters
S = kron(eye(N/2),ones(1,2));
Ksm = S*U;

output.kmax_charge = max(Ksm(:)); % maximum number of charging EVs at any charging station
output.obj = .5*u'*Q*u + d'*u; 
output.obj_smooth = u'*QL*u; 
output.res_C_norm = norm(C - sum(U,2));
output.res_C = C - sum(U,2);

end