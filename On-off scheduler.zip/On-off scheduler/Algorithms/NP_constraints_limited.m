function [c, ceq, gradc, gradceq] = NP_constraints_limited(x,K_tilde,w_tilde)

tau = 1e1; 
phi = 1./(1+ exp(-tau*(x - 0.5)));
c = (K_tilde*phi' - w_tilde);
ceq = [];

    if nargout > 2
       gradc = (K_tilde.*(ones(size(K_tilde,1),1)*(tau*exp(-tau*(x - 0.5))./(1+ exp(-tau*(x - 0.5))))'))';
       gradceq = [];
    end

end