function x = BQP_alter_function(fc,Q,c,A,b,Aeq,beq,inx,param)

% BLP solution
% options = optimoptions(@intlinprog,'LPOptimalityTolerance',1e-10,'RelativeGapTolerance',1e-8,...
%                       'ConstraintTolerance',1e-9,'IntegerTolerance',1e-6,'Display','off','MaxTime',param.Time_BLP);
                  
options = optimoptions('intlinprog','Heuristics','round','IntegerPreprocess','advanced',...
    'HeuristicsMaxNodes',500,'Display','off','MaxTime',param.Time_BLP);                  
Ai = A; Aeqi = Aeq; bi = b; beqi = beq;  

N = length(c);
xvars = 1:N;
zvar = N+1;

lb = zeros(N+1,1);
ub = ones(N+1,1);
ub(zvar) = Inf;

A = [A zeros(size(A,1),1)];
Aeq = [Aeq zeros(size(Aeq,1),1)];

lambda = 1;
f = [c; lambda];

%options = optimoptions(@intlinprog,'Display','off','MaxTime',param.Time_BLP); % Suppress iterative display
[xLinInt,fval,exitFlagInt,output] = intlinprog(f,xvars,A,b,Aeq,beq,lb,ub,options);
if isempty(xLinInt)
   [xLinInt,fval,exitFlagInt,output] = linprog(f,A,b,Aeq,beq,lb,ub);
end
xLinInt_prev = xLinInt;

thediff = 1e-4;
iter = 1; % iteration counter
assets = xLinInt(xvars); % the x variables
truequadratic = .5*assets'*Q*assets;
zslack = xLinInt(zvar); % slack variable value
%options = optimoptions(options,'LPOptimalityTolerance',1e-10,'RelativeGapTolerance',1e-8,...
%                      'ConstraintTolerance',1e-9,'IntegerTolerance',1e-6);

% options = optimoptions(options,'LPOptimalityTolerance',1e-10,'RelativeGapTolerance',1e-8,...
%                       'ConstraintTolerance',1e-9,'IntegerTolerance',1e-6,'MaxTime',param.Time_BLP);

history = [truequadratic,zslack];
Q = Q + 1e-8*eye(size(Q,1));

    while (abs((zslack - truequadratic)/truequadratic) > thediff) & (iter < 20) % relative error
        newArow = horzcat(assets'*Q,-1); % Linearized constraint
        rhs = .5*assets'*Q*assets;                     % right hand side of the linearized constraint
        A = [A;newArow];
        b = [b;rhs];
        inx_A = sum(A,2) < 1e-8;
        A(inx_A,:) = [];
        b(inx_A) = [];
        % Solve the problem with the new constraints
        [xLinInt,fval,exitFlagInt,output] = intlinprog(f,xvars,A,b,Aeq,beq,lb,ub,options);
        if isempty(xLinInt)
            disp('xLinInt is empty');
            xLinInt = xLinInt_prev;
            break
        else
            xLinInt_prev = xLinInt;
        end
        assets = (assets+xLinInt(xvars))/2; % Midway from the previous to the current
    %     assets = xLinInt(xvars); % Use the previous line or this one
        truequadratic = .5*xLinInt(xvars)'*Q* xLinInt(xvars);
        zslack = xLinInt(zvar);
        history = [history;truequadratic,zslack];
        iter = iter + 1;
        if output.numfeaspoints > 1
            break
        end
    end
    
    x = xLinInt(xvars); 

end