function [U,output] = scheduling_no_power_limit(B,C,param)

N = length(C);
T = size(B,1);
Ux = zeros([N T+max(C)]);

    for j = 1:N
        Tin(j) = min(find(B(:,j)));
    end

    for i = 1:N/2
        Tins = [Tin(2*i-1) Tin(2*i)]';
        [~,Inx] = min(Tins);
        if Inx == 1
            a_point = Tin(2*i-1)+C(2*i-1);            
            Ux(2*i-1,Tin(2*i-1):(a_point-1)) = 1;
            if a_point >=Tin(2*i)
                Ux(2*i,a_point:(a_point+C(2*i)-1)) = 1;
            else
                Ux(2*i,Tin(2*i):(Tin(2*i)+C(2*i)-1)) = 1;               
            end
        else
            a_point = Tin(2*i)+C(2*i);            
            Ux(2*i,Tin(2*i):(a_point-1)) = 1;
            if a_point >=Tin(2*i-1)                
               Ux(2*i-1,a_point:(a_point+C(2*i-1)-1)) = 1;            
            else
               Ux(2*i-1,Tin(2*i-1):(Tin(2*i-1)+C(2*i-1)-1)) = 1;                     
            end
        end    
    end
U = Ux(:,1:T);    

% Output parameters
S = kron(eye(N/2),ones(1,2));
Ksm = S*U;
L = eye(T) - diag(ones(T-1,1),1);
QL = kron(L*L',eye(N));
u = U(:);

output.kmax_charge = max(Ksm(:)); % maximum number of charging EVs at any charging station
output.obj = 1; 
output.obj_smooth = u'*QL*u;
output.counts = count_switches(U);
output.tardiness = max(find(sum(U,1)));
output.power_max = param.Uc*(sum(diag(param.I_EVs_X)*U,1)+sum(diag(param.I_EVs_Y)*U,1)+sum(diag(param.I_EVs_Z)*U,1));
output.res_C_norm = norm(C - sum(U,2));
output.res_C = C - sum(U,2);
output.max_current_X = sum((param.I_EVs_X*ones(1,T)).*U,1);
output.max_current_Y = sum((param.I_EVs_Y*ones(1,T)).*U,1);
output.max_current_Z = sum((param.I_EVs_Z*ones(1,T)).*U,1);

end