% Binary Linear Programming (BLP)
%
%% Input: 
% B - matrix of availbale time slots
% C - vector of energy demands
% parameters

%% Output
% U - binary matrix of output controlling variables 

function U = QP_2links_fun(B,C,param)

N = length(C); % number of availabe ports
T = size(B,1); % number of all time slots 
m = N*T; % number of variables
U = zeros(N,T);

%% Constraints 
B_tilde = kr(B,diag(ones(1,N)))'; % B_tilde u = C
Z_tilde = kron(eye(T),ones(1,N)); % Z_tilde u <= c_tilde
R_tilde = kron(eye(m/2),ones(1,2)); % 2 ports in one station
K_tilde = [Z_tilde; R_tilde]; % augmented matrix for inequality constraints
a = param.r0*ones(N,1);

Ex = ones([N/2 T]); ex = Ex(:); % R_tilde u <= ex
c_tilde = zeros(T,1); c_tilde(1:max(sum(B,1))) = param.P/param.r0; % assuming D = 0;
w_tilde = [c_tilde; ex];

%% Difference operator
L = eye(T) - diag(ones(T-1,1),1);
QL = kron(L*L',eye(N));

D = diag([ones(1,param.t_stop) ((param.w_max - 1)/(T-param.t_stop))*(1:T-param.t_stop) + 1]);
F = kron(D,ones(1,N));
Q = kron(D,a*a') + param.alpha*QL;
d = -F'*c_tilde; % vector in the objective: 1/2 x'Qx + d'x

% Algorithm
u = [];
options = optimoptions('quadprog','Algorithm','active-set','Display','iter-detailed');
u = quadprog(Q,d,K_tilde,w_tilde,[B_tilde; kron(ones(1,T),eye(N))],[C/param.r0; C/param.r0], ...
        zeros(T*N,1),ones(T*N,1)); 

if isempty(u)
    disp('Empty vector u');
   return
end
U = reshape(u,[N T]);

end