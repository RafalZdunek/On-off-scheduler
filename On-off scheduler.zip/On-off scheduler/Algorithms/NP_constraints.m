function [c, ceq, gradc, gradceq] = NP_constraints(x,K_tilde,w_tilde,K_eq,C)

tau = 1e3; 
phi = 1./(1+ exp(-tau*(x - 0.5)));
c = (K_tilde*phi' - w_tilde);
ceq = K_eq*phi' - C;

    if nargout > 2
       gradc = (K_tilde.*(ones(size(K_tilde,1),1)*(tau*exp(-tau*(x - 0.5))./(1+ exp(-tau*(x - 0.5))))'))';
       gradceq = (K_eq.*(ones(size(K_eq,1),1)*(tau*exp(-tau*(x - 0.5))./(1+ exp(-tau*(x - 0.5))))'))'; 
    end

end