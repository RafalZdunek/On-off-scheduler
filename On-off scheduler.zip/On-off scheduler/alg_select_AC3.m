function [U,output] = alg_select_AC3(B,C,algorithm,param)

switch algorithm
    
    case 1 % LP
    
        [U,output] = LP_2links_AC3_fun(B,C,param);
        
    case 2 % BLP
        
        [U,output] = BLP_2links_AC3_fun(B,C,param);
        
    case 3 % QP
        
        [U,output] = QP_2links_AC3_fun(B,C,param);
        
    case 4 % BQP
        
        [U,output] = BQP_ADMM_2links_AC3_fun(B,C,param);
        
    case 5 % FW-BQP-P
        
        [U,output] = FW_BQP_2links_AC3_P_optim_fun(B,C,param);
        
    case 6 % FW-BQP-C
        
        [U,output] = FW_BQP_2links_AC3_C_optim_fun(B,C,param);     
        
    case 7 % FW-BQP-C-NegGrad
        
        [U,output] = FW_BQP_2links_AC3_C_optim_neg_grad_fun(B,C,param);      
        
    case 8 % NP(GA-P)
        
        [U,output] = NP_2links_AC3_P_optim_fun(B,C,param);
        
    case 9 % NP(GA-C)
        
        [U,output] = NP_2links_AC3_C_optim_fun(B,C,param);
    
    case 10 % BQP(A-P)
        
        [U,output] = BQP_2links_AC3_P_optim_fun(B,C,param);
    
    case 11 % BQP(A-C)
        
        [U,output] = BQP_2links_AC3_C_optim_fun(B,C,param);
        
    case 12 % QP(Bin)
        
        [U,output] = QP_binarization_2links_AC3_fun(B,C,param);           
        
    case 13 % SNPL
        
        [U,output] = scheduling_no_power_limit(B,C,param);        
                
    case 14 % FW-BQP-C-no-smooth
        
        [U,output] = FW_BQP_2links_AC3_C_NoSmooth_optim_fun(B,C,param);     
        
    case 15 % BQP(A-C)-no-smooth
        
        [U,output] = BQP_2links_AC3_C_NoSmooth_optim_fun(B,C,param);       
        
end % switch

end 

