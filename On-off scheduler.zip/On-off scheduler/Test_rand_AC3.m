clear

% The Matlab code for reproducing the results from: 
% R. Zdunek, A. Grobelny, J. Witkowski, R. Gnot, 
% On--Off Scheduling for Electric Vehicle Charging in Two-Links Charging
% Stations Using Binary Optimization Approaches, Sensors, 2021

% Path setting
DataFolder = pwd;
addpath(fullfile(DataFolder,'Algorithms/'));

%% INPUTS:
MC_Runs = 1; % Monte Carlo runs
N = 16; % number of all available ports in loading stations; 
Imax = 50; % (A) maximum current per one phase of charging station 
T = 96; % max time slots (from 20.00 to 8.00, every 15 min.)
r0 = 16; % Amper/slot (assuming Level-2)
Uc = 230; % charging voltage 
t_stop = round(.1*T); % time interval from which the weighting applies 
w_max = 10; % maximum weighting
alpha = 1e-2; % penalty parameter
method_feasible = 1; % 1 - all above the critical point, 2 - one worst point     
% ================================================================

%% Benchmark
% 1 - restricted random (randi)
% 2 - fixed
benchmark = 1;

%% Algorithms
% 1- LP, 2 - BLP, 3 - QP, 4 - BQP(poor), 5 - FW-BQP-P, 6 - FW-BQP-C, 7 - FW-BQP-C-NegGrad, 8 - NP(GA-P), 9 - NP(GA-C), 
% 10 - BQP(A-P), 11 - BQP(A-C), 12 - QP(Bin), 
% 13 - Scheduling No Power (SNPL), 14 - FW-BQP-C-no-smooth, 15 - BQP(A-C)-no-smooth
alg_labels = {'LP','BLP','QP','BQP','FW-BQP-P','FW-BQP-C','FW-BQP-C-NegGrad','NP(GA-P)','NP(GA-C)',...
    'BQP(A-P)','BQP(A-C)','QP(Bin)','SNPL','FW-BQP-C-NSm','BQP(A-C-NSm)'};
%Algorithms = [2 5 6 7 10 11 13];
Algorithms = [11];

%% Parameters
param.r0 = r0;
param.t_stop = t_stop; 
param.w_max = w_max; 
param.Imax = Imax; 
param.alpha = alpha;
param.Uc = Uc; 
param.method_feasible = method_feasible; 
param.Time_BLP = 5;

% Initializations
U = zeros([N,T,max(Algorithms),MC_Runs]); 
B_mc = zeros([T,N,MC_Runs]); 
C_mc = zeros([N,MC_Runs]); 
Tx_mc = zeros([N,MC_Runs]); 
ET = zeros([max(Algorithms),MC_Runs]);
PowerMax = zeros([max(Algorithms),MC_Runs,T]);
kmax_charge = zeros([max(Algorithms),MC_Runs]);
Fobj = zeros([max(Algorithms),MC_Runs]);
Fsmooth = zeros([max(Algorithms),MC_Runs]);
Counts = zeros([max(Algorithms),MC_Runs]);
Tardiness = zeros([max(Algorithms),MC_Runs]);
ResCnorm = zeros([max(Algorithms),MC_Runs]);
param_mc = cell([1 MC_Runs]);

%% Monte Carlo (MC) runs
for k = 1:MC_Runs

%% Charging rates
% I_EVs = r0*ones(N,1); % maximum current of each EV taken in slot t, 
% I_EVs_X = I_EVs; I_EVs_Y = I_EVs; I_EVs_Z = I_EVs;

I_EVs_X = max(.1*r0,min(r0,2*r0*rand(N,1))); % maximum current of each EV taken in slot t
I_EVs_Y = max(.1*r0,min(r0,2*r0*rand(N,1))); % maximum current of each EV taken in slot t
I_EVs_Z = max(.1*r0,min(r0,2*r0*rand(N,1))); % maximum current of each EV taken in slot t

param.I_EVs_X = I_EVs_X; % (phase 1)
param.I_EVs_Y = I_EVs_Y; % (phase 2)
param.I_EVs_Z = I_EVs_Z; % (phase 3)

%% Data generation
[C,Tx,B] = data_generation_AC3(N,T,benchmark);

%% Feasibility
[C,uc] = feasibility_enforce(C,B,param);

%% Algorithms
for j = Algorithms
    disp(['MCrun: ',num2str(k),', alg = ',num2str(j)]);
    tic
    [Ux,output] = alg_select_AC3(B,C,j,param); 
    U(:,:,j,k) = Ux;
    ET(j,k) = toc;
    kmax_charge(j,k) = output.kmax_charge;
    Fobj(j,k) = output.obj; 
    Fsmooth(j,k) = output.obj_smooth;
    Counts(j,k) = output.counts;
    Tardiness(j,k) = output.tardiness;
    PowerMax(j,k,:) = output.power_max;
    ResCnorm(j,k) = output.res_C_norm;    
end

B_mc(:,:,k) = B;
C_mc(:,k) = C;
Tx_mc(:,k) = Tx;
param_mc{k} = param; 

end % MC

% Save data
outputFile = ['Scheduling_tmp_N_',num2str(N),'_Imax_',num2str(Imax)];
result = struct('Algorithms',Algorithms,...
                'Algorithms_Labels',alg_labels,...
                'benchamrk',benchmark,...
                'N', N,...
                'Imax', Imax,...
                'T',T,... 
                'MC_Runs',MC_Runs,...
                'alpha',alpha,...
                'method_feasible',method_feasible,...
                'C',C_mc,...
                'Tx',Tx_mc,...
                'B',B_mc,...
                'U',U,...
                'ET',ET,...
                'PowerMax',PowerMax,...
                'kmax_charge',kmax_charge,...
                'Fobj',Fobj,...
                'Fsmooth',Fsmooth,...
                'Counts',Counts,...
                'Tardiness',Tardiness,...
                'ResCnorm',ResCnorm);
%save(outputFile, 'result','param_mc');
    

%% Visualization
%TimeStamps = [2009,4,2,11,7,18; 2009,4,2,11,8,18; 2009,4,2,11,9,18];
TimeStamps = ones(7,6)*diag([2021, 09, 15, 1, 0, 0]);
TimeStamps(:,4) = [18, 20, 22, 0, 2, 4, 6]';
t = datestr(TimeStamps,'HH:MM');

for j = Algorithms
    figure
    s1 = subplot(2,1,1);
    imagesc(B')
    axis 'off'
    set(s1,'XTick',[1,T/6,2*T/6,3*T/6,4*T/6,5*T/6,T],'XTickLabel',t)
    axis 'on'
    xlabel('Available time slots')
    ylabel('ports')
    title([alg_labels{j}])
    grid on
    
    s2 = subplot(2,1,2);
    %imagesc(.1*B'+U)
    imagesc(squeeze(U(:,:,j)))
    axis 'off'
    set(s2,'XTick',[1,T/6,2*T/6,3*T/6,4*T/6,5*T/6,T],'XTickLabel',t)
    axis 'on'
    xlabel('Charging slots')
    ylabel('ports')
    title([alg_labels{j},', L_{EV} = ',num2str(sum(C > 0)),', L_{max} = ',num2str(max(sum(squeeze(U(:,:,j)),1)))])
    grid on
end

% figure
% plot(output{2}.power_max,'b')
% hold on
% plot(output{5}.power_max,'r')
% plot(output{6}.power_max,'g')
% plot(output{7}.power_max,'m')
% plot(output{10}.power_max,'c')
% plot(output{11}.power_max,'y')
% plot(output{13}.power_max,'k')
% plot(3*Uc*Imax*ones(1,T),'k')



