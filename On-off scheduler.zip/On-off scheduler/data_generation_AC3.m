function [C,Tx,B] = data_generation_AC3(N,T,benchmark)

% N - number of all available ports in loading stations; 
% T - max time slots 

%% ===========================================================================
%C = [30 10 10 8 10 8 4 15 30 10]'; % number of time slots needed to charge all EVs 
%Tx = [45 30 17 18 22 22 24 25 40 40]'; % available time slots 

% C = [30 0 10 0 10 0 4 0 30 0]'; % number of time slots needed to charge all EVs 
% Tx = [45 0 17 0 22 0 24 0 40 0]'; % available time slots 

%C = [10 8 14 8 4 16]'; % charge demands 
%Tx = [17 18 22 22 24 25]'; % available time
switch benchmark
    
    case 1 % randi

%% ==========================================================================

%% Plug-in time
Tin_mean = 10; Tin_std = 5; 
Tin = max(1,round(Tin_mean + Tin_std*randn([N 1])));
%Tin = ones(N,1);

%% Energy demand generation
C = zeros([N,1]);
Cmin = 4; Cmax = 30;
for i = 1:N
    C(i) = randi([Cmin min(Cmax,T-Tin(i)-Cmin)]);
    if ~mod(i,2)
        C(i) = randi([0 min(Cmax,max(0,(T-Tin(i)-C(i-1))))]);
    end
end

%% Time slot-generation
Tx = zeros([length(C) 1]);
for i = 1:length(C)
    Tx(i) = min(T,randi([(Tin(i)+C(i)) T]));
    if ~mod(i,2) & ((C(i)+Tin(i) + C(i-1)+Tin(i-1)) > max(Tx(i),Tx(i-1)))
        Tx(i) = min(T,C(i) + C(i-1)+Tin(i));
    end
end

    case 2 % fixed
    
    if N == 4
        
        C = [12    13     6    10]';
        Tx = [38    43    39    41]';
        
    elseif N == 6
        
        C = [15    25    25    12    16    23]';
        Tx = [40    31    41    36    21    26]'; 
        
    elseif N == 8
        
        C = [21     3     8    31    30     2    39     7]';
        Tx = [25    14    47    46    47    48    45    46]'; 
        
    elseif N == 10
        
        C = [30 10 10 8 10 8 4 15 30 10]'; % number of time slots needed to charge all EVs 
        Tx = [45 30 17 18 22 22 24 25 40 40]'; % available time slots 
        
    elseif N == 12
        
        C = [41     2    35     5    14    14     9     3    6     8    33     8]';
        Tx = [44     8    44    36    42    30     9    13    46    13    44    25]';
        
    elseif N == 14
        
        C = [5    16    33     6    30     6    25     7     4    10     8    16    25     5]';
        Tx = [ 26    40    39    27    44    23    29    48    34    47    17    24    41    17]';
        
    elseif N == 16       
        
         C = [ 16     6     9    35    10     5    30    12    38     7     7    13    14     5    35     10]';
         Tx = [31    32    27    47    22    33    40    42    45    14    11    29    37    39    47    22]';
        
    end
        
end % switch

%% Available time slots
%C = r0*C; % energy demand 
B = zeros(T,N);
for n = 1:N
    B(Tin(n):Tx(n),n) = 1; % binary matrix of avilable time slots for each EV
end


end
